My website
==========

work on my personal website
one block website
let's try to make it simple
with a 3d of me on the back
let's add some vignette effet too

change color with the day

Add vignette
change bg color slightliy birghter

for hosting.
paperplane.io
https://www.pythonanywhere.com/pricing/


I use to do some 2d/3d animation 
    now recicled in Python Development for (from data import data) %s years and %smonth now,

I use to some Vr, Unity/Unreal stuff, University Lecturer
    Suzzane Award wining, Special slection to Annecy, etc..

I am currently working For Fixstudio as
    Python Developen / R&D Engenier

you still can =>cantact me <=

Put a link to my cv, and linkedin on top right corner
top left corner put JS experiences too
/smile
/3dofme
/black
/bronw nad stuff