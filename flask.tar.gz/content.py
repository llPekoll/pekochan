from flask import Markup
from datetime import datetime

years= ''
month= ''

about = Markup("""
        <p>
            my name is Yohann, 
            <span id="small">I use to do some 2d/3d animation </span>
            now recicled in <span id="different">Python Development</span> for %s years and %smonth now,
        </p>
        <p>
            I use to some Vr, Unity/Unreal stuff, University Lecturer
            Suzzane Award wining, Special slection to Annecy, etc..
        </p> 
        <p>
            I am currently working For Fixstudio as
            Python Developen / R&D Engenier

            you still can =>cantact me <=
        </p>"""), % (years, months)

rand_name = ['Mamadou', 'La Grenouille', 'Mon Chelly']


### inspiration
## https://kentatoshikura.com/
## http://findmatthew.com/
## https://pierre.io/
## http://www.michaelvillar.com/
## https://optimo.com/
## http://slyillustrations.com/
## https://www.eliwilliamson.com/
## http://www.drama.xxx/

## lib 
## http://animejs.com/
## http://mojs.io/
## http://three.js/

# # host
#  https://www.pythonanywhere.com/forums/topic/1496/